package com.festival.tickets.entity.models;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "grupos")
public class TesteoBandas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String name;
    private String stage;
    private String start_time;
    private String end_time;
    private int set_time;
    private int day;
    private String img;

    @ManyToMany(mappedBy = "grupos")
    private List<Horario> horarios;

    public TesteoBandas() {
    }

    public TesteoBandas(long id, String name, String stage, String start_time, String end_time, int set_time, int day, String img) {
        this.id = id;
        this.name = name;
        this.stage = stage;
        this.start_time = start_time;
        this.end_time = end_time;
        this.set_time = set_time;
        this.day = day;
        this.img = img;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public int getSet_time() {
        return set_time;
    }

    public void setSet_time(int set_time) {
        this.set_time = set_time;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }
}
