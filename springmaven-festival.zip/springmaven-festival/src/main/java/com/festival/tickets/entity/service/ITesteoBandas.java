package com.festival.tickets.entity.service;

import com.festival.tickets.entity.models.TesteoBandas;
import com.festival.tickets.entity.models.Tickets;

import java.util.List;

public interface ITesteoBandas {

    public TesteoBandas get(long id);
    public List<TesteoBandas> getAll();
    public void post(TesteoBandas grupo);
    public void put(TesteoBandas grupo, long id);
    public void delete(long id);
}
