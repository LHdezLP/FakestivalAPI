package com.festival.tickets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmavenFestivalApplicationTests {

	@Test
	void contextLoads() {
	}

}
