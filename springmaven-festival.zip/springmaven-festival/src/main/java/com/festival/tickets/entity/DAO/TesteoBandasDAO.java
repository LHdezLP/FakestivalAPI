package com.festival.tickets.entity.DAO;

import com.festival.tickets.entity.models.TesteoBandas;
import org.springframework.data.repository.CrudRepository;

public interface TesteoBandasDAO extends CrudRepository<TesteoBandas, Long> {
}
