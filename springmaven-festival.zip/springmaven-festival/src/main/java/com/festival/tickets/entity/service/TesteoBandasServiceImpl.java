package com.festival.tickets.entity.service;

import com.festival.tickets.entity.DAO.TesteoBandasDAO;
import com.festival.tickets.entity.models.TesteoBandas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TesteoBandasServiceImpl implements ITesteoBandas {

    @Autowired
    private TesteoBandasDAO gruposDao;

    @Override
    public TesteoBandas get(long id) {
        return gruposDao.findById(id).orElse(null);
    }

    @Override
    public List<TesteoBandas> getAll() {
        return (List<TesteoBandas>) gruposDao.findAll();
    }

    @Override
    public void post(TesteoBandas grupo) {
        gruposDao.save(grupo);
    }

    @Override
    public void put(TesteoBandas grupo, long id) {
        TesteoBandas existente = gruposDao.findById(id).orElse(null);
        if (existente != null) {
            existente.setName(grupo.getName());
            existente.setStage(grupo.getStage());
            existente.setStart_time(grupo.getStart_time());
            existente.setEnd_time(grupo.getEnd_time());
            existente.setSet_time(grupo.getSet_time());
            existente.setImg(grupo.getImg());
            gruposDao.save(existente);
        }
    }

    @Override
    public void delete(long id) {
        gruposDao.deleteById(id);
    }
}
