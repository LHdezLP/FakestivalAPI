package com.festival.tickets.controllers;

import com.festival.tickets.entity.models.TesteoBandas;
import com.festival.tickets.entity.service.ITesteoBandas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/grupos")
@CrossOrigin(origins = "*")
public class TesteoBandasController {

    @Autowired
    private ITesteoBandas bandasService;


    @GetMapping
    public List<TesteoBandas> getAllBandas() {
        return bandasService.getAll();
    }

    @GetMapping("/{id}")
    public TesteoBandas getBandaById(@PathVariable long id) {
        return bandasService.get(id);
    }

    @PostMapping
    public void createBanda(@RequestBody TesteoBandas banda) {
        bandasService.post(banda);
    }

    @PutMapping("/{id}")
    public void updateBanda(@RequestBody TesteoBandas banda, @PathVariable long id) {
        bandasService.put(banda, id);
    }

    @DeleteMapping("/{id}")
    public void deleteBanda(@PathVariable long id) {
        bandasService.delete(id);
    }
}
