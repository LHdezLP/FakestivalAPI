package com.festival.tickets.controllers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.festival.tickets.entity.DAO.TesteoBandasDAO;
import com.festival.tickets.entity.models.TesteoBandas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.festival.tickets.entity.models.Horario;
import com.festival.tickets.entity.service.IHorarioService;

@CrossOrigin(origins = "*")
@RequestMapping("/api")
@RestController
public class HorarioController {

    @Autowired
    IHorarioService horarioService;

    @Autowired
    private TesteoBandasDAO bandaDao;

    @GetMapping("horarios")
    public List<Horario> getAllHorarios() {
        return horarioService.getAll();
    }

    @GetMapping("/horarios/{id}")
    public Horario getOne(@PathVariable(value = "id") long id) {
        return horarioService.get(id);
    }

    @PostMapping("/horarios")
    public ResponseEntity<Horario> post(@RequestBody Horario horario) {
        if (horario.getGrupos() != null && !horario.getGrupos().isEmpty()) {
            Set<TesteoBandas> bandasPersistidas = new HashSet<>();
            for (TesteoBandas banda : horario.getGrupos()) {
                TesteoBandas b = bandaDao.findById(banda.getId()).orElse(null);
                if (b != null) {
                    bandasPersistidas.add(b);
                }
            }
            horario.setGrupos(bandasPersistidas);
        }
        horario.setId_horario(null);
        horarioService.post(horario);
        return new ResponseEntity<>(horario, HttpStatus.CREATED);
    }

    @PutMapping("/horarios/{id}")
    public void put(@PathVariable(value = "id") long id, @RequestBody Horario horario) {
        horarioService.put(horario, id);
    }

    @DeleteMapping("/horarios/{id}")
    public void delete(@PathVariable(value = "id") long id) {
        horarioService.delete(id);
    }
}