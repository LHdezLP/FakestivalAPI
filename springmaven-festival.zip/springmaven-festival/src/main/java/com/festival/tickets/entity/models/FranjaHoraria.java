package com.festival.tickets.entity.models;

public enum FranjaHoraria {
    FRANJA_1, // 14:00 - 14:55
    FRANJA_2, // 15:00 - 15:55
    FRANJA_3  // 16:00 - 16:55
}
