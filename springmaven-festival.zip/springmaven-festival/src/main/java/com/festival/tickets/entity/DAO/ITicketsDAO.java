package com.festival.tickets.entity.DAO;

import java.util.List;

import com.festival.tickets.entity.dto.TicketReportDTO;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.festival.tickets.entity.models.Tickets;

public interface ITicketsDAO extends CrudRepository<Tickets, Long>{
	
	@Query("SELECT t FROM Tickets t WHERE t.type = :type")
    List<Tickets> findByType(@Param("type") String type);

    @Query("SELECT new com.festival.tickets.entity.dto.TicketReportDTO(t.type, COUNT(t), SUM(t.price)) " +
            "FROM Tickets t WHERE t.adquirido = true GROUP BY t.type")
    List<TicketReportDTO> getTicketReport();

}
