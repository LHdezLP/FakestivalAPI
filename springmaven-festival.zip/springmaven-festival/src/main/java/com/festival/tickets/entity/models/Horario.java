package com.festival.tickets.entity.models;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "horarios")
public class Horario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_horario;

    private String name;

    /*@ManyToOne
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;*/

    @ManyToMany
    @JoinTable(
            name = "horario_banda",
            joinColumns = @JoinColumn(name = "id_horario"),
            inverseJoinColumns = @JoinColumn(name = "id_banda")
    )
    private Set<TesteoBandas> grupos = new HashSet<>();

    public Horario() {
    }

    public Long getId_horario() {
        return id_horario;
    }

    public void setId_horario(Long id_horario) {
        this.id_horario = id_horario;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<TesteoBandas> getGrupos() {
        return grupos;
    }

    public void setGrupos(Set<TesteoBandas> grupos) {
        this.grupos = grupos;
    }
}
