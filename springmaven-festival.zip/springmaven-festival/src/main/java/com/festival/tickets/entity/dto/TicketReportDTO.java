package com.festival.tickets.entity.dto;

public class TicketReportDTO {
    private String type;
    private Long sold;
    private Double revenue;

    public TicketReportDTO(String type, Long sold, Double revenue) {
        this.type = type;
        this.sold = sold;
        this.revenue = revenue;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Long getSold() {
        return sold;
    }

    public void setSold(Long sold) {
        this.sold = sold;
    }

    public Double getRevenue() {
        return revenue;
    }

    public void setRevenue(Double revenue) {
        this.revenue = revenue;
    }
}
